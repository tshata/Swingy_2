package za.co.wethinkcode.swingy.models.artefacts;

import za.co.wethinkcode.swingy.models.artefacts.Artefact;

public class Weapon extends Artefact {
    @Override
    public int increaseValue() {
        return 0;
    }
}
