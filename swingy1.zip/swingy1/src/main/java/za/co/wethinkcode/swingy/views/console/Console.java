package za.co.wethinkcode.swingy.views.console;

import za.co.wethinkcode.swingy.views.View;

public class Console extends View {
}
