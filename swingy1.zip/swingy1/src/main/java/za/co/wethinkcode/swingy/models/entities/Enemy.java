package za.co.wethinkcode.swingy.models.entities;

public abstract class Enemy implements Entity{

    public void fight() {

    }
}
