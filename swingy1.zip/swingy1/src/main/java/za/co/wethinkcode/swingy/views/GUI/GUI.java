package za.co.wethinkcode.swingy.views.GUI;

import za.co.wethinkcode.swingy.views.View;

public class GUI extends View {
}
