package za.co.wethinkcode.swingy.views;

public class GUI extends View {
}
