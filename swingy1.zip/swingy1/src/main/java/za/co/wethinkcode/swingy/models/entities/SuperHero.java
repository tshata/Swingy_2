package za.co.wethinkcode.swingy.models.entities;

import za.co.wethinkcode.swingy.models.artefacts.Artefact;

public class SuperHero extends Hero {
    public Artefact artefact() {
        return null;
    }
}
