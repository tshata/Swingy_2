package za.co.wethinkcode.swingy.views;

public class Console extends View {
}
