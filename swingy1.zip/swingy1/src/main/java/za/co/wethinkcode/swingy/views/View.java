package za.co.wethinkcode.swingy.views;

public abstract class View {

    public void createHero(){

    }

    public void selectHero() {

    }
}
