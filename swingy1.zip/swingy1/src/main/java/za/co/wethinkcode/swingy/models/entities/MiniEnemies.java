package za.co.wethinkcode.swingy.models.entities;

import za.co.wethinkcode.swingy.models.artefacts.Artefact;

public class MiniEnemies extends Enemy {
    public void fight() {

    }

    public void run() {

    }

    public void pickUpArtefact() {

    }

    public Artefact artefact() {
        return null;
    }
}
