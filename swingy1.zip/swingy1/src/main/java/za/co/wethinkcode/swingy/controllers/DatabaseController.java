package za.co.wethinkcode.swingy.controllers;

public class DatabaseController {
}
