package za.co.wethinkcode.swingy.models.entities;

public abstract class Hero implements Entity {

    private String name;
    private String rank;
    private int level;
    private int attack;
    private int defence;
    private int hitPoints;

    public void fight() {

    }

    public void run() {

    }

    public void pickUpArtefact() {

    }

}
